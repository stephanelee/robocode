# MeridianPeak v1: registered acquisition

Protocol: [issue #95](https://github.com/stephanelee/robocode/issues/95) and
[prospective method](../../docs/improvements/meridian-peak-v1.md).

Status: source/JAR/tool freeze independently reviewed; no screen or confirmation
games have run. [Draft PR #96](https://github.com/stephanelee/robocode/pull/96).
Freeze SHA256: `07e72b257dea6f9c81217ff1143bb87addb300fa650bf0d7374b216ac24e973c`.
Local preparation and contract tests establish implementation properties only.

The screen is five cold five-round games, in `games.json` order. A complete valid
screen PASS is required before the unchanged candidate's nine fresh twenty-round
confirmation games. Stop at the first invalidity; preserve partial evidence and
never replace or resume an acquisition. Each stage has its own permanent receipt.

`preparation/` preserves local build/test/parity commands, logs and provenance.
Hosted zero-game preflight and both acquisition stages use the pinned workflow
`.github/workflows/meridian-peak-v1.yml`. Every hosted job runs Ubuntu 26.04;
Java 17 builds/tests precede the Java 25 match runtime. Runtime/profile or frozen
payload mismatches prevent collection. Profile-label runs cannot start games.

Own private skips are polled during execution. Observer-only skips and all other
recording/model validity checks are evaluated at the completed-game boundary
before the next game. The observer never supplies data to bot policy code.

Keep full original recordings, logs, commands, explicit own model snapshots,
runtime/package/host/receipt documents and hashes. Results and a standalone
independent audit will be linked here after the sole screen attempt.

Hosted zero-game [preflight41779652044](https://github.com/stephanelee/robocode/actions/runs/41779652044)
passed at head `ed58717805d7bb4d1aff333cabeb02709ad380c0`, allowed image
`20261026.180.1`. [Full original ZIP, log, runtime and preparation evidence](preflight/run-41779652044/)
are preserved. ZIP SHA256: `68282d4bb7a715d314a38d3e28d57a996a5b3387c270f882e5b5063526f49df4`.
Both acquisition jobs were skipped; no durable acquisition receipt was created.

Screen-label [run41780412075](https://github.com/stephanelee/robocode/actions/runs/41780412075)
failed before admission/activation/game startup when the harness repeated fresh
venv construction. **0 physical games/rounds; no comparative result.**
[Full original ZIP parts, log, preparation and runtime evidence](preflight/failed-screen-preparation-41780412075/)
are retained. `reassemble.py` restores the exact ZIP20619a387320f7e88549b96404cf7b8a66d49cebd96ffdd170e97a1b44c20fc2.
The old freeze is preserved under `registration/`; preparation repair requires a
new tooling freeze, hosted zero-game path check and independent screen clearance.

Collection/verification repair independently reviewed:21/21 ordinary harness tests
pass; [source review and logs](preparation/collect-once-repair/). Only tooling,
protocol bookkeeping and preparation provenance changed in the new freeze above.
All25 participant assets, schedule, runtime family, packages and success criteria
match the preserved original registration. A fresh zero-game hosted profile must
exercise collect-once followed by two read-only verifications before any renewed
exact-head screen clearance. The screen and confirmation receipts remain unused.
