import argparse,json,os,shutil,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import benchmark
p=argparse.ArgumentParser();p.add_argument('--freeze',type=Path,required=True);args=p.parse_args()
root=Path.cwd();base=Path('/tmp/facet-melee-adapter');output=base/'attempt-1';freeze=json.loads(args.freeze.read_text())
assert not output.exists()
for rel,h in freeze['fileSHA256'].items():
 assert benchmark.digest(root/rel)==h,rel
assert benchmark.digest(base/'FacetContractBattle.java')==freeze['harnessSHA256']
assert benchmark.digest(base/'probe/ContractPartner.java')==freeze['probeSHA256']
assert benchmark.digest(base/'probe/ContractPartner.class')==freeze['probeClassSHA256']
assert benchmark.digest(base/'FacetContractBattle.class')==freeze['harnessClassSHA256']
assert benchmark.digest(base/'run.py')==freeze['acquisitionSHA256']
assert benchmark.digest(Path('/tmp/facet-build/robocode-tankroyale-runner-1.4.0.jar'))==freeze['runnerSHA256']
assert benchmark.digest(Path('/tmp/facet-clean-room/official/robocode-tankroyale-bot-api-1.4.0.jar'))==freeze['apiSHA256']
output.mkdir();shutil.copy2(args.freeze,output/'registration.json')
report={'status':'running','games':[],'purpose':'bounded actual active melee integration, no competitive interpretation'}
def save(): (output/'status.json').write_text(json.dumps(report,indent=2)+'\n')
save();java='/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home/bin/java';begin=time.monotonic()
try:
 for index,seed in enumerate((49667,49668)):
  if time.monotonic()-begin>350:raise RuntimeError('insufficient remaining600second budget')
  run=output/f'game-{index+1}';run.mkdir();bot=run/'Facet';bot.mkdir()
  for name in ('Facet.jar','Facet.json','Facet.sh'):shutil.copy2(root/'experiments/Facet'/name,bot/name)
  (bot/'Facet.sh').chmod(0o755)
  partners=[]
  for label in ('ContractAlpha','ContractBeta'):
   partner=run/label;partner.mkdir();partners.append(partner)
   for name in ('ContractPartner.java','ContractPartner.class'):shutil.copy2(base/'probe'/name,partner/name)
   shutil.copy2('/tmp/facet-clean-room/official/robocode-tankroyale-bot-api-1.4.0.jar',partner/'api.jar')
   descriptor=dict(name=label,version='1.0',authors=['Stéphane Lee'],gameTypes=['1v1','melee'],platform='JVM17',programmingLang='Java17')
   (partner/(label+'.json')).write_text(json.dumps(descriptor)+'\n')
   (partner/(label+'.sh')).write_text('#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nexec "$JAVA_HOME/bin/java" -cp .:api.jar ContractPartner '+label+'\n')
   (partner/(label+'.sh')).chmod(0o755)
  prefixes=('FACET_','AISURVIVOR_','RETCON_','ROBOCODE_','CHALLENGER_')
  env={k:v for k,v in os.environ.items() if not k.startswith(prefixes) and k not in ('SERVER_URL','SERVER_SECRET','BOT_SECRET','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS')}
  env.update(JAVA_HOME=str(Path(java).parents[1]),PATH=str(Path(java).parent)+os.pathsep+env.get('PATH',''),FACET_SEED=str(seed),FACET_METRICS_PATH=str(run/'FACET_metrics.jsonl'),FACET_TRACE_PATH=str(run/'FACET_trace.jsonl'),FACET_STATE_PATH=str(run/'FACET_model.dat'),FACET_PROBE_ROOT=str(run))
  order=[bot,*partners] if index==0 else [*partners,bot]
  item={'seed':seed,'rounds':2,'launchOrder':[p.name for p in order],'status':'running'};report['games'].append(item);save()
  cmd=[java,'-cp','/tmp/facet-build/robocode-tankroyale-runner-1.4.0.jar'+os.pathsep+str(base),'FacetContractBattle',str(run/'battle.json'),*map(str,order)]
  item['launchArgv']=cmd;item['privateEnvironment']={k:v for k,v in env.items() if k.startswith('FACET_')};save()
  benchmark.run_process(cmd,root,env,run/'runner.log',250)
  time.sleep(.2)
  result=json.loads((run/'battle.json').read_text());metrics=[json.loads(x) for x in (run/'FACET_metrics.jsonl').read_text().splitlines()]
  if result['numberOfRounds']!=2 or len(metrics)!=2:raise ValueError('incomplete game')
  item.update(status='complete',official=result);save()
 report['status']='complete'
except BaseException as e:report.update(status='invalid',error=str(e));raise
finally:report['elapsedSeconds']=time.monotonic()-begin;save()
